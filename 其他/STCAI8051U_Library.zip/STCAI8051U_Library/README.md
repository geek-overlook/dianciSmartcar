![逐飞LOGO](https://images.gitee.com/uploads/images/2019/0924/114256_eaf16bad_1699060.png "逐飞科技logo 中.png")

# 逐飞科技AI8051U开源库

#### 简介

逐飞科技针对参加各类竞赛以及使用AI8051U进行产品开发，制作的AI8051U开源库。

#### 环境准备

1.  **AI8051U硬件环境：** 

- 推荐使用本公司AI8051U核心板，[点击此处购买](https://item.taobao.com/item.htm?id=858128049156&pisk=f8bo_5Thug-53Hkk1oY7YWON19rxPYTBB93ppepU0KJjygF5eDxFBOxEJuTJxeX2HapRwUJE-9Cdy9CFJB7HPZI-JLeW-6W9-ReTWPC5N3TUBRB4-pky7Chr8vdPgEy-HA2uWPC5ibdz6szOyrKSWhde83-FgjJXtbuFL35q3KOBTY8eUSf2P8NzPiVfWkKwIYZA97W3nUvNaL5RNZ8sBdfyA20HEQxu2_Jm827c0PElTLrsMpTJFtOldPgWzHjFyE7z3y8NftbHbFqLN35hm9TRuWoyQgBJAZtmU0RMrLxNztlslsxFmZYRzJi1MsvyjEIYc8KprTj6C3rbh9fDe97k0YjPEmoZZ63Cb1aoADtyGIvOnUyZUZxAV0V0ic-B4IO7oSVmADtyGIvTiSmNN3RXNrf..&skuId=5835076302781&spm=a1z10.3-c.w4002-22508770840.9.498749ccbZTkoW)。

2.  **软件开发环境：** 
    （MDK FOR C251）

- MDK 推荐使用版本：V5.60。

3.  **下载器：** 
    （核心板自带）

- 核心板自带有USB转串口芯片，只需要插上TYPE-C数据线即可实现下载功能。
- USB转TTL：推荐使用本公司USB转TTL，[点击此处购买](https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-22508770840.9.12dc49ccL93dhG&id=524829874577)。

3.  **使用外部晶振：** 

- 开源库中，默认使用40Mhz的外部晶振。


#### 使用说明

1.  **下载开源库：** 点击页面右侧的克隆/下载按钮，将工程文件保存到本地。您可以使用git克隆（Clone）或下载ZIP压缩包的方式来下载。推荐使用git将工程目录克隆到本地，这样可以使用git随时与我们的开源库保持同步。关于码云与git的使用教程可以参考以下链接 [https://gitee.com/help](https://gitee.com/help)。
2.  **打开工程：** 将下载好的工程文件夹打开（若下载的为ZIP文件，请先解压压缩包）。在打开工程前，请务必确保您的IDE满足环境准备章节的要求。

#### 逐飞科技AI8051U核心板

![逐飞科技AI8051U核心板](https://img.alicdn.com/imgextra/i3/2364650632/O1CN01RRb5iO1GXVKMzRT0D_!!2364650632.jpg_.webp "逐飞科技AI8051U核心板.jpg")


