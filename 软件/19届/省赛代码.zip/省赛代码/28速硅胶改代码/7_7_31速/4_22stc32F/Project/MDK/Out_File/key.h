#ifndef _KEY_H_
#define _KEY_H_

void key(void);


extern char bizhangSTARTFlag;
extern char motor_start;
extern char key_function_flag;
extern char cricle_order;
extern char bizhang_order;
extern char cricle_function_switch;

#endif
