#ifndef _OLED_H_
#define _OLED_H_

extern int time_counter;
extern int ips_counter;
extern int8 ips_page;

extern void IPS_page_show(void);
extern void IPS(void);

extern char cricle_count_order;
#endif

