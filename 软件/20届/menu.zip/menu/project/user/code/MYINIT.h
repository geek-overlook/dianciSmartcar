#ifndef   _MYINIT_H
#define  _MYINIT_H
#include "zf_common_headfile.h"

void  MyInit(void);


#endif