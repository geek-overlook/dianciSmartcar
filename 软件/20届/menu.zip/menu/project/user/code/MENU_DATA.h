#ifndef   _MENU_DATA_H
#define   _MENU_DATA_H
#include "zf_common_headfile.h"

#define flash_k1_addr 0x00
#define flash_k2_addr 0x004
#define flash_k3_addr 0x008
#define flash_k4_addr 0x00C
#define flash_k5_addr 0x010
#define flash_k6_addr 0x014
#define flash_k7_addr 0x018
#define flash_k8_addr 0x01C
#define flash_k9_addr 0x020
#define flash_k10_addr 0x024
#define flash_k11_addr 0x028
#define flash_k12_addr 0x02C
#define flash_k13_addr 0x030
#define flash_k14_addr 0x034
#define flash_k15_addr 0x038
#define flash_k16_addr 0x03C
#define flash_k17_addr 0x040
#define flash_k18_addr 0x044
#define flash_k19_addr 0x048
#define flash_k20_addr 0x04C
#define flash_k21_addr 0x050
#define flash_k22_addr 0x054
#define flash_k23_addr 0x058
#define flash_k24_addr 0x05C
#define flash_k25_addr 0x060
#define flash_k26_addr 0x064
#define flash_k27_addr 0x068
#define flash_k28_addr 0x06C
#define flash_k29_addr 0x070
#define flash_k30_addr 0x074
#define flash_k31_addr 0x078
#define flash_k32_addr 0x07C
#define flash_k33_addr 0x080
#define flash_k34_addr 0x084
#define flash_k35_addr 0x088
#define flash_k36_addr 0x08C
#define flash_k37_addr 0x090
#define flash_k38_addr 0x094
#define flash_k39_addr 0x098
#define flash_k40_addr 0x09C
#define flash_k41_addr 0x0A0
#define flash_k42_addr 0x0A4
#define flash_k43_addr 0x0A8
#define flash_k44_addr 0x0AC
#define flash_k45_addr 0x0B0
#define flash_k46_addr 0x0B4
#define flash_k47_addr 0x0B8
#define flash_k48_addr 0x0BC
#define flash_k49_addr 0x0C0
#define flash_k50_addr 0x0C4

void Data_Init(void);
void read_flash(void);
void write_flash(void);
void Speed_Chose(int8 change);



#endif