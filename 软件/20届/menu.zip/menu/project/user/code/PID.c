#include "zf_common_headfile.h"

_PID Gyroy_PID,WPitch_PID,Speed_PID,Servo_PID,Go_Speed_PID;
_PID YGyrox_PID,Yaw_angle_PID,YSpeed_PID;
_PID TGyroz_PID,Turn_PID,TSpeed_PID;

