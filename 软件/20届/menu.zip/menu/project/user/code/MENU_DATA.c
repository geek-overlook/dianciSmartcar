#include "zf_common_headfile.h"

//#include "data.h"
//#include "lcd.h"

//void Data_Init(void)
//{
//    pitch_filter.DT=0.01169;    
//    pitch_filter.Gyro_rabo=0.041;

//    roll_filter.DT=0.01169;
//    roll_filter.Gyro_rabo=0.041;
//    PID_Init();
//}

//uint8 speed_mode;
//void Speed_Chose(int8 change)
//{

//    speed_chose+=change;
//    speed_chose%=5;
//    if(speed_chose==0)
//    {
//        speed_chose=4;
//    }

//    flash_buffer_clear();
//    flash_union_buffer[0].int32_type = speed_chose;

//    if(flash_check(FLASH_SECTION_INDEX, FLASH_PAGE_INDEX))                     
//       flash_erase_page(FLASH_SECTION_INDEX, FLASH_PAGE_INDEX);                
//    flash_write_page_from_buffer(FLASH_SECTION_INDEX, FLASH_PAGE_INDEX);


//}
int flash[20]={0};
uint16 address = 0x00; // ��ʼ��ַ

void read_flash(void)
{
			int i;
			for(i=0;i<20;i++){
					iap_read_buff(address,(uint8 *)&flash[i],4);
					address+=4;
			}
//			iap_read_buff(address,flash,4);
			start_speed=flash[0];
			wifi_flag=flash[1];
	
			
			
//       Gyroy_PID.kp = flash[1];
//       Gyroy_PID.ki = flash[2];

//       WPitch_PID.kp = flash[3];
//       WPitch_PID.kd = flash[4];

//       k_e1 = flash_union_buffer[5].float_type;
//       k_e2 = flash_union_buffer[6].float_type;

//       Speed_PID.kp = flash_union_buffer[7].float_type;
//       Speed_PID.kd  = flash_union_buffer[10].float_type;

//       YGyrox_PID.kp = flash_union_buffer[8].float_type;
//       start_speed = flash_union_buffer[11].int16_type;

//       image_flag= flash_union_buffer[12].uint8_type;
//       wifi_flag = flash_union_buffer[13].uint8_type;
//       Servo_PID.kp = flash_union_buffer[14].float_type;

//       front_dot_s = flash_union_buffer[15].uint8_type;
//       k_e3 = flash_union_buffer[16].float_type;
//       k_e4 = flash_union_buffer[17].float_type;

//       Turn_PID.kp = flash_union_buffer[18].float_type;
//       k_lost = flash_union_buffer[19].float_type;
//       k_e5 = flash_union_buffer[20].float_type;

}

void write_flash(void)
{

//       flash_buffer_clear();
					iap_erase_page(0);
					iap_write_buff(0x00, (uint8*)&start_speed, 4);
					iap_write_buff(0x04, (uint8*)&wifi_flag, 4);

//       flash_union_buffer[1].float_type = Gyroy_PID.kp;
//       flash_union_buffer[2].float_type = Gyroy_PID.ki;


//       flash_union_buffer[3].float_type = WPitch_PID.kp;
//       flash_union_buffer[4].float_type = WPitch_PID.kd;



//       flash_union_buffer[5].float_type = k_e1;
//       flash_union_buffer[6].float_type = k_e2;


//       flash_union_buffer[7].float_type = Speed_PID.kp;
//       flash_union_buffer[10].float_type = Speed_PID.kd;


//       flash_union_buffer[8].float_type = YGyrox_PID.kp;
//       flash_union_buffer[11].int16_type = start_speed;

//       flash_union_buffer[12].uint8_type = image_flag;
//       flash_union_buffer[13].uint8_type = wifi_flag;
//       flash_union_buffer[14].float_type = Servo_PID.kp;

//       flash_union_buffer[15].uint8_type = front_dot_s;
//       flash_union_buffer[16].float_type = k_e3;
//       flash_union_buffer[17].float_type = k_e4;

//       flash_union_buffer[18].float_type = Turn_PID.kp;
//       flash_union_buffer[19].float_type = k_lost;
//       flash_union_buffer[20].float_type = k_e5;
}

//void write_flash(void)
//{
//
//       flash_buffer_clear();
//
//       flash_union_buffer[1].float_type = 115.09;//Gyroy_PID.kp;
//       flash_union_buffer[2].float_type = 7.81;//Gyroy_PID.ki;
//
//
//       flash_union_buffer[3].float_type = 1.27;//WPitch_PID.kp;
//       flash_union_buffer[4].float_type = 0.35;//WPitch_PID.kd;
//
//
//       flash_union_buffer[5].float_type = 4.03;//k_e1;
//       flash_union_buffer[6].float_type = 9.15;//k_e2;
//
//
//       flash_union_buffer[7].float_type = 11.7;//Speed_PID.kp;
//       flash_union_buffer[10].float_type = 0.9;//Speed_PID.kd;
//
//
//       flash_union_buffer[8].float_type = 0.34;//YGyrox_PID.kp;
//       flash_union_buffer[11].int16_type = 3000;//start_speed;
//
//       flash_union_buffer[12].uint8_type = image_flag;
//       flash_union_buffer[13].uint8_type = wifi_flag;
//       flash_union_buffer[14].float_type = 1.63;//Servo_PID.kp;
//
//       flash_union_buffer[15].uint8_type = 37;//front_dot_s;
//       flash_union_buffer[16].float_type = 10.22;//k_e3;
//       flash_union_buffer[17].float_type = 9.13;//k_e4;
//
//       flash_union_buffer[18].float_type = 1.567;//Turn_PID.kp;
//       flash_union_buffer[19].float_type = 0.061;//k_lost;
//       flash_union_buffer[20].float_type = 8.82;//k_e5;
//}


