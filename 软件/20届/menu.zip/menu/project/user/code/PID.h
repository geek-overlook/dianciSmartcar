#ifndef   _PID_H
#define   _PID_H
#include "zf_common_headfile.h"

typedef struct{
       float kp;
       float ki;
       float kd;
       float kp1;
       float kp2;

       int limit_max;
       int limit_min;

       float integral_max;
       float integral_min;

       float err;
       float err_sum;
       float err_last;
       float d_err;

       float out;
       float integral_out;
       float kp_out;
       float kd_out;
       float kd_lastout;
       float Target;
       float now;

       float filter;
}_PID;

extern _PID Gyroy_PID,WPitch_PID,Speed_PID,Servo_PID,YGyrox_PID,Yaw_angle_PID,Go_Speed_PID,Turn_PID;


#endif