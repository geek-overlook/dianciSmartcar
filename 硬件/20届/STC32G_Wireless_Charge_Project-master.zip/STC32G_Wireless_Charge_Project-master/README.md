![逐飞LOGO](https://images.gitee.com/uploads/images/2019/0924/114256_eaf16bad_1699060.png "逐飞科技logo 中.png")
# 逐飞科技基于STC32G无线充电发射端开源项目

#### 介绍

逐飞科技精心设计的基于STC32G开发的的无线充电发射端参考方案。使用3S-6S电池供电，采用全桥移相控制方案，硬件框图如下：
![输入图片说明](Resource/Hardware_architecture.png)

#### 环境准备

1.  **软件开发环境：** 
（MDK FOR C251）
- MDK 推荐使用版本：5.37
2.  **下载器：** 
- USB转TTL：推荐使用本公司USB转TTL，[点击此处购买](https://item.taobao.com/item.htm?spm=a1z10.3-c-s.w4002-22508770840.9.12dc49ccL93dhG&id=524829874577)。

#### 软件架构说明

软件框图构成
![输入图片说明](Resource/Software_architecture.png)

#### 使用说明

1.  在使用无线发射端时，请务必确认接线牢固，以12V供电为例，当以150W额定功率发射时，会在供电线路上产生150W/12V=12.5A的电流！如果接线不牢固，就有可能导致严重的虚接发热，引起不可预料的后果！（发热严重融化焊锡导致短路、引发PCB烧毁等）
![输入图片说明](Resource/Power_connector.png)
2.  当发射端正常供电时，会首先开启供电监测，如果供电电压范围正确，会显示识别的供电电池类型，例如输入电压为12V时，会在数码管上显示“3S”的字样。
![输入图片说明](Resource/Battery_type_identification.png)
3.  如果接入的是2S电池，那么数码管则会显示“Er”，表示输入电压过低不能正常工作，如果接入的3S锂电池电压低于11.2V，就会显示“Lo”代表电池电量不足，可能无法正常工作。
![输入图片说明](Resource/System_abnormal.png)
4.在测试时，可以不接使能端口的EN信号，或者将EN信号短接到GND，这样无线发射端就处于按键控制模式，通过按键可以启动发射，在停止状态时数码管显示“--” 。
![输入图片说明](Resource/Stop_state.png)
5.此时按下发射按键就进入无线发射模式，数码管以0.1倍率十进制数显示功率，也就是说数码管显示“1”时，实际功率为10W，显示“15”时实际功率为150W。
![输入图片说明](Resource/Transmitting_state.png)
