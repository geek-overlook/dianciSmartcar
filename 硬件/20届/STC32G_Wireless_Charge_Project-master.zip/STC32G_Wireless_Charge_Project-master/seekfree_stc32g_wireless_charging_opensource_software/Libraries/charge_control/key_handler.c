/*********************************************************************************************************************
* seekfree_stc32g_wireless_charge_opensource_software 即（STC32G 无线充电开源软件）
* 是一个基于官方 SDK 接口的开源软件
* Copyright (c) 2022 SEEKFREE 逐飞科技
* 
* 本文件是 STC32G 无线充电开源软件的一部分
* 
* STC32G 无线充电开源软件 是免费软件
* 您可以根据自由软件基金会发布的 GPL（GNU General Public License，即 GNU通用公共许可证）的条款
* 即 GPL 的第3版（即 GPL3.0）或（您选择的）任何后来的版本，重新发布和/或修改它
* 
* 本开源库的发布是希望它能发挥作用，但并未对其作任何的保证
* 甚至没有隐含的适销性或适合特定用途的保证
* 更多细节请参见 GPL
* 
* 您应该在收到本开源库的同时收到一份 GPL 的副本
* 如果没有，请参阅<https://www.gnu.org/licenses/>
* 
* 额外注明：
* 本开源库使用 GPL3.0 开源许可证协议 以上许可申明为译文版本
* 许可申明英文版在 libraries/doc 文件夹下的 GPL3_permission_statement.txt 文件中
* 许可证副本在 libraries 文件夹下 即该文件夹下的 LICENSE 文件
* 欢迎各位使用并传播本程序 但修改内容时必须保留逐飞科技的版权声明（即本声明）
* 
* 文件名称          key_handler
* 公司名称          成都逐飞科技有限公司
* 版本信息          查看 libraries/doc 文件夹内 version 文件 版本说明
* 开发环境          MDK 5.37
* 适用平台          STC32G
* 店铺链接          https://seekfree.taobao.com/
* 
* 修改记录
* 日期              作者                备注
* 2023-01-04        Teternal            first version
* 2024-11-28        Teternal            STC32G migration
********************************************************************************************************************/

#include "zf_gpio.h"

#include "driver_interface.h"
#include "charge_control.h"
#include "pit_handler.h"
#include "key_handler.h"

#pragma warning disable = 183
#pragma warning disable = 177

volatile    uint8   key_button_state        = 0;
volatile    uint8   key_button_last_state   = 0;
volatile    uint16  key_button_keep_state   = 0;
volatile    uint16  key_en_keep_state       = 0;

//-------------------------------------------------------------------------------------------------------------------
// 函数简介    按键动作 处理函数
// 参数说明     void
// 返回参数     void
// 使用示例     key_handler();
// 备注信息     
//-------------------------------------------------------------------------------------------------------------------
void key_handler (void)
{
    // 按键检测
    if(CHARGE_TEST_PLUS_ENABLE || KEN_EN_FILTER_LOW > key_en_keep_state)
    {
        if(!gpio_get_level(KEY_BUTTON_PIN))
        {
            key_button_keep_state = (KEY_MAX_SHOCK_PERIOD > key_button_keep_state) ? (key_button_keep_state + PIT_HANDLER_SYSTEM_PERIOD_MS) : (KEY_MAX_SHOCK_PERIOD);
        }
        else
        {
            if(key_button_keep_state == KEY_MAX_SHOCK_PERIOD)
            {
                key_button_state = 1;
            }
            key_button_keep_state = 0;
        }
        if(key_button_state)
        {
            if(CHARGE_CLOSE == charge_state)
            {
                charge_congrol_enable(ZF_ENABLE);
                charge_state = CHARGE_OPEN;
            }
            else
            {
                charge_congrol_enable(ZF_DISABLE);
                charge_state = CHARGE_CLOSE;
            }
            key_button_state = 0;
        }
    }

#if(!CHARGE_TEST_PLUS_ENABLE)
    if(gpio_get_level(KEY_EN_PIN))
    {
        key_en_keep_state = (KEN_EN_FILTER_DEPTH > key_en_keep_state) ? (key_en_keep_state + PIT_HANDLER_SYSTEM_PERIOD_MS) : (KEN_EN_FILTER_DEPTH);
        if(KEN_EN_FILTER_HIGH == key_en_keep_state  && CHARGE_LOW_POWER != charge_state && CHARGE_ERR != charge_state)
        {
            charge_congrol_enable(ZF_ENABLE);
            charge_state = CHARGE_OPEN;
        }
    }
    else
    {
        key_en_keep_state = (0 < key_en_keep_state) ? (key_en_keep_state - PIT_HANDLER_SYSTEM_PERIOD_MS) : (0);
        if(KEN_EN_FILTER_LOW == key_en_keep_state && (CHARGE_OPEN == charge_state || CHARGE_STANDBY == charge_state) )
        {
            charge_congrol_enable(ZF_DISABLE);
            charge_state = CHARGE_CLOSE;
        }
    }
#endif
}

//-------------------------------------------------------------------------------------------------------------------
// 函数简介    按键处理 初始化
// 参数说明     void
// 返回参数     void
// 使用示例     key_init();
// 备注信息     
//-------------------------------------------------------------------------------------------------------------------
void key_init (void)
{
    gpio_mode(KEY_BUTTON_PIN, GPI_OD);
    gpio_set_level(KEY_BUTTON_PIN, 1);

#if(!CHARGE_TEST_PLUS_ENABLE)
    gpio_mode(KEY_EN_PIN, GPI_OD);
    gpio_set_level(KEY_EN_PIN, 1);
#endif
}
