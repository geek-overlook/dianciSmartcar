/*********************************************************************************************************************
* seekfree_stc32g_wireless_charge_opensource_software 即（STC32G 无线充电开源软件）
* 是一个基于官方 SDK 接口的开源软件
* Copyright (c) 2022 SEEKFREE 逐飞科技
* 
* 本文件是 STC32G 无线充电开源软件的一部分
* 
* STC32G 无线充电开源软件 是免费软件
* 您可以根据自由软件基金会发布的 GPL（GNU General Public License，即 GNU通用公共许可证）的条款
* 即 GPL 的第3版（即 GPL3.0）或（您选择的）任何后来的版本，重新发布和/或修改它
* 
* 本开源库的发布是希望它能发挥作用，但并未对其作任何的保证
* 甚至没有隐含的适销性或适合特定用途的保证
* 更多细节请参见 GPL
* 
* 您应该在收到本开源库的同时收到一份 GPL 的副本
* 如果没有，请参阅<https://www.gnu.org/licenses/>
* 
* 额外注明：
* 本开源库使用 GPL3.0 开源许可证协议 以上许可申明为译文版本
* 许可申明英文版在 libraries/doc 文件夹下的 GPL3_permission_statement.txt 文件中
* 许可证副本在 libraries 文件夹下 即该文件夹下的 LICENSE 文件
* 欢迎各位使用并传播本程序 但修改内容时必须保留逐飞科技的版权声明（即本声明）
* 
* 文件名称          power_sample
* 公司名称          成都逐飞科技有限公司
* 版本信息          查看 libraries/doc 文件夹内 version 文件 版本说明
* 开发环境          MDK 5.37
* 适用平台          STC32G
* 店铺链接          https://seekfree.taobao.com/
* 
* 修改记录
* 日期              作者                备注
* 2023-01-04        Teternal            first version
* 2024-11-28        Teternal            STC32G migration
********************************************************************************************************************/

#ifndef _power_sample_h_
#define _power_sample_h_

#include "charge_config.h"

// ----------------------- 功率采样 信号宏定义 -----------------------
// 模块与引脚的配置需要对照 引脚功能列表、原理图 来进行选择
// ADC 部分
#define CHARGE_ADC_VOLTAGE_CHANNEL              ( ADC_P10 )
#define CHARGE_ADC_CURRENT_CHANNEL              ( ADC_P11 )

#define CHARGE_ADC_REF_VOLTAGE                  ( 5000.0  )                     // 参考电压 mV
#define CHARGE_ADC_RESOLUTION_MAX               ( 4096.0  )                     // ADC 采样精度最大值
// ----------------------- 功率采样 信号宏定义 -----------------------

// ----------------------- 功率采样 计算宏定义 -----------------------
#define CHARGE_SAMPLING_RES                     ( 2.0 )                         // 总线电流采样电阻阻值 mR 毫欧单位
#define CHARGE_BATTERY_CELLS_VOLTAGE            ( 4400 )                        // 电池电芯电压上限 mV
#define CHARGE_BATTERY_CELLS_LOW_LIMIT          ( 3700 )                        // 电池电芯电压下限 mV 低于这个电压会进入低电压状态
#define CHARGE_VOLTAGE_LOW_LIMIT                ( 11000 )                       // 输入电压下限 mV 低于这个电压会进入错误状态
#define CHARGE_VOLTAGE_HIGH_LIMIT               ( 26200 )                       // 输入电压上限 mV 高于这个电压会进入错误状态

#define CHARE_OVER_MAX_POWER_COUNT_MAX          ( 5 )

#define CHARGE_ADC_SMOOTHING_NUMBER             ( 10 )                          // ADC 平滑滤波深度
#define CHARGE_ADC_SAMPLES_NUMBER               ( 10 )                          // ADC 原始数据采样次数
#define CHARGE_ADC_USE_DATA_NUMBER              ( 4  )                          // ADC 原始数据滤波后使用的数据个数
                                                                                // 例如 16 次采样 4 个数据使用
                                                                                // 那么就是连续采集 16 个数据
                                                                                // 然后排序后取中间 4 个数据的平均数

#define CHARGE_ADC_DATA_START                   ( (CHARGE_ADC_SAMPLES_NUMBER - CHARGE_ADC_USE_DATA_NUMBER) / 2 )
#define CHARGE_ADC_DATA_END                     ( CHARGE_ADC_SAMPLES_NUMBER - CHARGE_ADC_DATA_START - 1 )
// ----------------------- 功率采样 计算宏定义 -----------------------

// ----------------------- 功率校准 宏定义 -----------------------
// y = 0.989246 x + 622.693704 
#define CHARGE_VOLTAGE_FACTOR_MAX               ( 1 )                           // 电压测量校准公式最高次项
#define CHARGE_VOLTAGE_FACTOR_3                 ( 0.0 )                         // 电压测量校准系数 在有电流线性偏差时使用 这是三次项
#define CHARGE_VOLTAGE_FACTOR_2                 ( 0.0 )                         // 电压测量校准系数 在有电流线性偏差时使用 这是二次项
#define CHARGE_VOLTAGE_FACTOR_1                 ( 0.989246 )                    // 电压测量校准系数 在有电流线性偏差时使用 这是一次项
#define CHARGE_VOLTAGE_FACTOR_0                 ( 622.693704 )                  // 电压测量校准系数 在有电流线性偏差时使用 这是常数项

// y = 1.03 x + 0.0
#define CHARGE_POWER_FACTOR_MAX                 ( 1 )                           // 功率测量校准公式最高次项
#define CHARGE_POWER_FACTOR_3                   ( 0.0 )                         // 功率测量校准系数 在有电流线性偏差时使用 这是三次项
#define CHARGE_POWER_FACTOR_2                   ( 0.0 )                         // 功率测量校准系数 在有电流线性偏差时使用 这是二次项
#define CHARGE_POWER_FACTOR_1                   ( 1.05 )                        // 功率测量校准系数 在有电流线性偏差时使用 这是一次项
#define CHARGE_POWER_FACTOR_0                   ( 0.0 )                         // 功率测量校准系数 在有电流线性偏差时使用 这是常数项

// 关于如何自行校准功率
// 首先校准电压 将电压校准次项修改为 0 并将所有系数修改为 0 恢复未校准状态
// 开启 charge_config.h 中的 DEBUG_OUTPUT_ENABLE 然后编译程序并烧录
// 随后上电连接调试下载器 在调试串口上可以看到输出的电压信息
// 采集 12V - 24V 的电压数据 采样点越多越好
// 将显示数据与实际电压输入到 excel 竖向两排 然后选中所有数据 插入图表散点图
// 然后点击散点图右键添加趋势线 调整选择几次项或者线性 勾选显示公式
// 点击公式然后在选项最右侧的类别选数字 小数位数填 6 然后复制公式过来
// 线性拟合次项填 1 然后几次项就填几 随后填入电压校准宏定义即可
// 然后校准功率 使用阻性负载进行功率测试
// 将功率校准次项修改为 0 并将所有系数修改为 0 恢复未校准状态
// 开启 charge_config.h 中的 DEBUG_PWM_OUTPUT 然后编译程序并烧录
// 可以适当提高 charge_config.h 中的 CHARGE_MAX_TARGET 避免直接报错
// 修改对应的移相来控制功率 可以直接用 DEBUG_OUTPUT_ENABLE 使能的 main.c 中的分支控制移相
// 输入十六进制 0x00-0x0E 控制 10%-45% * 180° 的移相角
// 此时相当于开环运行 请确保接收端能够承受这么大功率
// 接着采集数据用 excel 拟合再将数据填入功率校准宏定义即可
// ----------------------- 功率校准 宏定义 -----------------------

extern  volatile    uint16  charge_display_power;
extern  volatile    uint8   charge_battery_cell_count;

extern  volatile    uint16  charge_power_over_max_count;
extern  volatile    float   charge_power;
extern  volatile    float   bus_voltage;
extern  volatile    float   bus_current;

void    power_sample_check_battery  (void);
void    power_sample_handler        (void);
void    power_sample_init           (void);

#endif

