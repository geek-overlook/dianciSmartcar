/*********************************************************************************************************************
* seekfree_stc32g_wireless_charge_opensource_software 即（STC32G 无线充电开源软件）
* 是一个基于官方 SDK 接口的开源软件
* Copyright (c) 2022 SEEKFREE 逐飞科技
*
* 本文件是 STC32G 无线充电开源软件的一部分
*
* STC32G 无线充电开源软件 是免费软件
* 您可以根据自由软件基金会发布的 GPL（GNU General Public License，即 GNU通用公共许可证）的条款
* 即 GPL 的第3版（即 GPL3.0）或（您选择的）任何后来的版本，重新发布和/或修改它
*
* 本开源库的发布是希望它能发挥作用，但并未对其作任何的保证
* 甚至没有隐含的适销性或适合特定用途的保证
* 更多细节请参见 GPL
*
* 您应该在收到本开源库的同时收到一份 GPL 的副本
* 如果没有，请参阅<https://www.gnu.org/licenses/>
*
* 额外注明：
* 本开源库使用 GPL3.0 开源许可证协议 以上许可申明为译文版本
* 许可申明英文版在 libraries/doc 文件夹下的 GPL3_permission_statement.txt 文件中
* 许可证副本在 libraries 文件夹下 即该文件夹下的 LICENSE 文件
* 欢迎各位使用并传播本程序 但修改内容时必须保留逐飞科技的版权声明（即本声明）
*
* 文件名称          driver_interface
* 公司名称          成都逐飞科技有限公司
* 版本信息          查看 libraries/doc 文件夹内 version 文件 版本说明
* 开发环境          MDK 5.37
* 适用平台          STC32G
* 店铺链接          https://seekfree.taobao.com/
*
* 修改记录
* 日期              作者                备注
* 2023-01-04        Teternal            first version
* 2024-11-28        Teternal            STC32G migration
********************************************************************************************************************/

#include "driver_interface.h"

#pragma warning disable = 183
#pragma warning disable = 177

void gpio_set_level (PIN_enum pin, uint8 value)
{
    uint8 temp_data = (0x01 << (pin & 0x0F));

    switch(pin & 0xF0)
    {
        case 0x00:  (value) ? (P0 |= temp_data) : (P0 &= ~temp_data);   break;
        case 0x10:  (value) ? (P1 |= temp_data) : (P1 &= ~temp_data);   break;
        case 0x20:  (value) ? (P2 |= temp_data) : (P2 &= ~temp_data);   break;
        case 0x30:  (value) ? (P3 |= temp_data) : (P3 &= ~temp_data);   break;
        case 0x40:  (value) ? (P4 |= temp_data) : (P4 &= ~temp_data);   break;
        case 0x50:  (value) ? (P5 |= temp_data) : (P5 &= ~temp_data);   break;
        case 0x60:  (value) ? (P6 |= temp_data) : (P6 &= ~temp_data);   break;
        case 0x70:  (value) ? (P7 |= temp_data) : (P7 &= ~temp_data);   break;
        default:    break;
    }
}

uint8 gpio_get_level (PIN_enum pin)
{
    uint8 temp_data = (0x01 << (pin & 0x0F));

    switch(pin & 0xF0)
    {
        case 0x00:  temp_data = (temp_data & P0) ? (1) : (0);   break;
        case 0x10:  temp_data = (temp_data & P1) ? (1) : (0);   break;
        case 0x20:  temp_data = (temp_data & P2) ? (1) : (0);   break;
        case 0x30:  temp_data = (temp_data & P3) ? (1) : (0);   break;
        case 0x40:  temp_data = (temp_data & P4) ? (1) : (0);   break;
        case 0x50:  temp_data = (temp_data & P5) ? (1) : (0);   break;
        case 0x60:  temp_data = (temp_data & P6) ? (1) : (0);   break;
        case 0x70:  temp_data = (temp_data & P7) ? (1) : (0);   break;
        default:    break;
    }

    return temp_data;
}
